from distutils.core import setup

setup(
	name='WPCC',
	version='0.1a',
	py_modules=['wpcc'],
	author='David Burks',
	author_email='davidburks@my.unt.edu',
	url='https://github.com/djburks/WPCC',
	)


